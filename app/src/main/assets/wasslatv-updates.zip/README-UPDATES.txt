وصلة TV (WasslaTV) — حزمة جميع التعديلات الجديدة
==================================================

محتويات هذه الحزمة:
1. آلية تحميل المصادر وإحصائيات المحتوى:
   - public/css/source-loader.css (جديد)
   - public/js/source-loader.js (جديد)
   - public/js/app.js · public/js/settings.js · public/js/xtream.js · public/js/xtream-txt.js

2. تحديثات المكتبة (VOD) والبطاقة التعريفية:
   - شريط التقدم أسفل بوستر الفيلم
   - تبويب «★ المفضلة» وزر النجمة السريع
   - بطاقة الفيلم التعريفية (قائمة الممثلين، سنة الإنتاج، تقييم IMDb)
   - قسم «✨ مقترح لك» للأفلام المشابهة عبر API
   - public/css/vod.css · public/css/vodplay.css · public/js/vod.js · public/js/vod-metadata.js · public/js/vod-model.js

3. إصلاح أخطاء التشغيل (403) والوسيط والخادم:
   - server.ts · package.json · tsconfig.json · vite.config.ts · .env.example
   - public/js/web-compat.js · public/js/libs.js · public/js/loading.js · public/js/receiver.js · public/js/quickpanel.js · public/css/receiver.css
   - index.html

طريقة الإضافة والبناء (مشروع Node / Vite):
1. فك الضغط داخل مجلد المشروع الرئيسي مع استبدال الملفات المتطابقة.
2. أنشئ ملف .env وضع فيه GEMINI_API_KEY="مفتاحك" لتفعيل اقتراحات الأفلام المشابهة.
3. نفّذ الأوامر التالية:
   npm install
   npm run build
   npm run dev   (أو npm start للتشغيل الإنتاجي)

ملاحظة لتطبيق أندرويد / الويب الساكن (بدون مجلد public):
- انسخ محتوى public/css/* إلى css/
- انسخ محتوى public/js/* إلى js/
- استبدل index.html
